def _path_inject(paths):
    import sys
    sys.path[:0] = paths
